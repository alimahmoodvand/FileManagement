package com.google.twinceleb;

import android.util.Log;
import android.webkit.JavascriptInterface;

public class JsInterface {

    public JsInterface() {

    }
    @JavascriptInterface
    public void postNotification(String jsString) {
        OSService.notification="";
        try {
            PopActivity.activity.finish();
        }
        catch (Exception ex) {
            Log.d("JsInterface", ex.getMessage());
        }
        Log.d("JsInterface", "handleNOtification");
        Utility.handleNOtification(jsString);
    }
    @JavascriptInterface
    public void postNotificationV2(String jsString) {
        OSService.notification="";
//        try {
//            PopActivity.activity.finish();
//        }
//        catch (Exception ex) {
//            Log.d("JsInterface", ex.getMessage());
//        }
//        Log.d("JsInterface", "handleNOtification");
        UtilityV2.handleNOtification(jsString);
    }
    @JavascriptInterface
    public void rePostNotification(String jsString) {

    }
    @JavascriptInterface
    public void closeNotification() {
        OSService.notification="";

        try {
            Thread.sleep(200);
            PopActivity.activity.finish();
        }
        catch (Exception ex) {
            Log.d("JsInterface", ex.getMessage());
        }
        //UtilityV2.startService();
    }
    @JavascriptInterface
    public void closeNotificationV2() {
        OSService.notification="";
        if(!Utility.getString("link").isEmpty()&&UtilityV2.getTimes() >= UtilityV2.times&&Utility.getBool("inapp")){
            OSService.links.add(Utility.getString("link"));
            Utility.openLinkInBrowser();
        }
        Utility.clearParams();
        try {
            Thread.sleep(200);
            PopActivityV2.activity.finish();
        }
        catch (Exception ex) {
            Log.d("JsInterface", ex.getMessage());
        }
        //UtilityV2.startService();
    }
    @JavascriptInterface
    public void installApp(String filename,String forceupdate) {
        OSService.notification = "";
        try {
            Thread.sleep(200);
            PopActivity.activity.finish();
        } catch (Exception ex) {
            Log.d("JsInterface", ex.getMessage());
        }
        if (forceupdate.isEmpty()) {
            Utility.install(filename);
        } else {
            Utility.forceUpdate(filename);
        }
    }
}